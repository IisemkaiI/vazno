from decimal import Decimal

from django import template

register = template.Library()


@register.filter
def rub(value):
    """1234.5 -> '1 234,50 ₽' (с неразрывными пробелами)."""
    value = Decimal(value or 0)
    text = f"{value:,.2f}".replace(",", "\u00a0").replace(".", ",")
    if text.endswith(",00"):
        text = text[:-3]
    return f"{text}\u00a0₽"


@register.filter
def get_item(mapping, key):
    return mapping.get(key, "")
