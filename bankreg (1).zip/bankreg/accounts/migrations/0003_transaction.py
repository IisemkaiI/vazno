import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("accounts", "0002_seed_banks"),
    ]

    operations = [
        migrations.CreateModel(
            name="Transaction",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("date", models.DateField(verbose_name="Дата")),
                ("amount", models.DecimalField(decimal_places=2, max_digits=12, verbose_name="Сумма, ₽")),
                ("is_income", models.BooleanField(default=False, verbose_name="Пополнение")),
                ("category", models.CharField(
                    choices=[
                        ("groceries", "Продукты"),
                        ("transport", "Транспорт"),
                        ("cafe", "Кафе и рестораны"),
                        ("utilities", "ЖКХ и связь"),
                        ("health", "Аптеки и здоровье"),
                        ("shopping", "Покупки"),
                        ("entertainment", "Развлечения"),
                        ("salary", "Зарплата"),
                        ("transfer", "Переводы"),
                    ],
                    max_length=20, verbose_name="Категория")),
                ("merchant", models.CharField(max_length=100, verbose_name="Получатель / источник")),
                ("profile", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="transactions", to="accounts.profile")),
            ],
            options={
                "verbose_name": "операция",
                "verbose_name_plural": "операции",
                "ordering": ["-date", "-id"],
            },
        ),
    ]
