from django.db import migrations

BANKS = [
    ("Т-Банк (Тинькофф)", "tinkoff", "#FFDD2D", "#1F1F1F", "Дебетовые и кредитные карты, онлайн-обслуживание"),
    ("Сбербанк", "sber", "#21A038", "#FFFFFF", "Крупнейший банк страны, вклады и переводы"),
    ("Альфа-Банк", "alfa", "#EF3124", "#FFFFFF", "Карты, накопительные счета и кэшбэк"),
]


def seed(apps, schema_editor):
    Bank = apps.get_model("accounts", "Bank")
    for name, slug, color, text_color, tagline in BANKS:
        Bank.objects.update_or_create(
            slug=slug,
            defaults={"name": name, "color": color, "text_color": text_color, "tagline": tagline},
        )


def unseed(apps, schema_editor):
    apps.get_model("accounts", "Bank").objects.filter(
        slug__in=[b[1] for b in BANKS]
    ).delete()


class Migration(migrations.Migration):

    dependencies = [("accounts", "0001_initial")]

    operations = [migrations.RunPython(seed, unseed)]
