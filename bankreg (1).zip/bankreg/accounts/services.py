"""Генерация демонстрационных операций (настоящего банка у нас нет)."""
import random
from datetime import timedelta
from decimal import Decimal

from django.utils import timezone

from .models import Category as C
from .models import Transaction

# категория: (вес, мин. сумма, макс. сумма, магазины)
EXPENSES = {
    C.GROCERIES: (10, 150, 2800, ["Пятёрочка", "Магнит", "ВкусВилл", "Перекрёсток", "Лента"]),
    C.TRANSPORT: (5, 60, 1500, ["Метро", "Яндекс Go", "АЗС", "Автобус"]),
    C.CAFE: (4, 200, 2200, ["Кофемания", "Шоколадница", "Додо Пицца", "Столовая"]),
    C.HEALTH: (1, 250, 3000, ["Аптека", "Аптека 36,6", "Клиника"]),
    C.SHOPPING: (2, 500, 7000, ["Wildberries", "Ozon", "Спортмастер", "М.Видео"]),
    C.ENTERTAINMENT: (2, 200, 2500, ["Кинотеатр", "Кинопоиск", "Steam"]),
}


def _money(low, high):
    return Decimal(random.randint(low * 100, high * 100)) / 100


def seed_demo_transactions(profile, days=90):
    today = timezone.localdate()
    rows = []
    cats = list(EXPENSES)
    weights = [EXPENSES[c][0] for c in cats]

    for offset in range(days):
        day = today - timedelta(days=offset)

        for _ in range(random.choices([0, 1, 2, 3], weights=[2, 5, 3, 1])[0]):
            cat = random.choices(cats, weights=weights)[0]
            _, low, high, shops = EXPENSES[cat]
            rows.append(Transaction(profile=profile, date=day, amount=_money(low, high),
                                    category=cat, merchant=random.choice(shops)))

        if day.day == 10:
            rows.append(Transaction(profile=profile, date=day, amount=_money(4000, 7000),
                                    category=C.UTILITIES, merchant="ЖКУ, квартплата"))
        if day.day == 15:
            rows.append(Transaction(profile=profile, date=day, amount=Decimal("650"),
                                    category=C.UTILITIES, merchant="Мобильная связь"))
        if day.day == 5:
            rows.append(Transaction(profile=profile, date=day, amount=_money(48000, 52000),
                                    is_income=True, category=C.SALARY, merchant="Зарплата"))
        if day.day == 20:
            rows.append(Transaction(profile=profile, date=day, amount=_money(30000, 34000),
                                    is_income=True, category=C.SALARY, merchant="Аванс"))

    Transaction.objects.bulk_create(rows)
