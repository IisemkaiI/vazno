from datetime import timedelta

from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Q, Sum
from django.shortcuts import redirect, render
from django.utils import timezone

from .forms import RegistrationForm
from .models import Bank, Category


def home(request):
    return render(request, "accounts/home.html", {"banks": Bank.objects.all()})


def register(request):
    if request.user.is_authenticated:
        return redirect("dashboard")

    form = RegistrationForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(request, "Готово! Счёт открыт, добро пожаловать.")
        return redirect("dashboard")

    selected = request.POST.get("bank") or request.GET.get("bank")
    return render(request, "accounts/register.html", {
        "form": form,
        "banks": Bank.objects.all(),
        "selected_bank": str(selected) if selected else "",
    })


def _get_profile(request):
    profile = getattr(request.user, "profile", None)
    if profile is None:  # например, суперпользователь из createsuperuser
        messages.info(request, "У этой учётной записи нет банковского профиля.")
    return profile


@login_required
def dashboard(request):
    profile = _get_profile(request)
    if profile is None:
        return redirect("home")

    totals = profile.transactions.aggregate(
        income=Sum("amount", filter=Q(is_income=True)),
        spent=Sum("amount", filter=Q(is_income=False)),
    )
    balance = (totals["income"] or 0) - (totals["spent"] or 0)
    return render(request, "accounts/dashboard.html", {
        "profile": profile,
        "balance": balance,
        "recent": profile.transactions.all()[:5],
    })


PERIODS = {"7": "7 дней", "30": "30 дней", "90": "90 дней"}
EXPENSE_CATEGORIES = [c for c in Category if c not in (Category.SALARY, Category.TRANSFER)]


@login_required
def expenses(request):
    profile = _get_profile(request)
    if profile is None:
        return redirect("home")

    period = request.GET.get("period", "30")
    if period not in PERIODS:
        period = "30"
    category = request.GET.get("category", "")
    if category not in {c.value for c in EXPENSE_CATEGORIES}:
        category = ""

    since = timezone.localdate() - timedelta(days=int(period))
    ops = profile.transactions.filter(date__gte=since, is_income=False)
    if category:
        ops = ops.filter(category=category)

    total = ops.aggregate(s=Sum("amount"))["s"] or 0
    labels = dict(Category.choices)
    by_category = [
        {
            "name": labels[row["category"]],
            "total": row["total"],
            "percent": round(row["total"] / total * 100) if total else 0,
        }
        for row in ops.values("category").annotate(total=Sum("amount")).order_by("-total")
    ]

    page = Paginator(ops, 15).get_page(request.GET.get("page"))
    params = request.GET.copy()
    params.pop("page", None)

    return render(request, "accounts/expenses.html", {
        "profile": profile,
        "total": total,
        "by_category": by_category,
        "page": page,
        "periods": PERIODS,
        "period": period,
        "categories": EXPENSE_CATEGORIES,
        "category": category,
        "querystring": params.urlencode(),
    })
