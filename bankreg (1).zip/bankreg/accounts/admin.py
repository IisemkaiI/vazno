from django.contrib import admin

from .models import Bank, Profile, Transaction


@admin.register(Bank)
class BankAdmin(admin.ModelAdmin):
    list_display = ("name", "slug", "color")


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "bank", "phone", "account_number", "created_at")
    list_filter = ("bank",)
    search_fields = ("user__username", "user__email", "phone", "account_number")
    readonly_fields = ("account_number", "created_at")


@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    list_display = ("date", "profile", "merchant", "category", "amount", "is_income")
    list_filter = ("category", "is_income")
    search_fields = ("merchant", "profile__user__username")
